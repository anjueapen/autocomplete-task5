import "./searchList.css";
export const SearchList = ({ searchListVal }) => {
  console.log(searchListVal);
  return (
    <div className="list-container">
      {searchListVal.map((data) => (
        <div className="list-items" key={data.id}>
          <img
            height="32px"
            width="32px"
            style={{ objectFit: "contain" }}
            src={`https://image.tmdb.org/t/p/w500/${data.poster_path}`}
            alt=""
          />
          <p className="title">{data.title}</p>
        </div>
      ))}
    </div>
  );
};
