import { SearchInput } from "./searchInput/searchInput";
import { SearchList } from "./searchList/searchList";
import "./Search.css";
import { useEffect, useState } from "react";
import axios from "axios";

export const Search = () => {
  const [searchInputVal, setSearchInputVal] = useState("");
  const [searchListVal, setSearchListVal] = useState([]);
  const handleChange = (event) => {
    setSearchInputVal(event.target.value);
    const newList = searchListVal.filter((data) => {
      data?.title.toLowerCase().includes(event.target.value);
    });
    console.log(newList);

    setSearchListVal(newList);
  };
  const API_URL =
    "https://api.themoviedb.org/3/search/movie?api_key=d3449ff6ec0c027623bf6b6f5fff78b3&language=en-US&page=1&include_adult=false";
  //locally
  const fetchSearchList = async () => {
    try {
      const response = await axios(API_URL, {
        params: {
          query: "movie",
        },
      });
      // Saving to local array to filter locally
      setSearchListVal(response.data.results);
      console.log(response.data.results);
      //setFilteredList(response.data.results);
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    fetchSearchList();
  }, []);
  return (
    <div className="search-container">
      <div className="search-header">
        <img
          height="32px"
          width="32px"
          src="https://cdn-icons-png.flaticon.com/512/3917/3917132.png"
          alt=""
        />
        <h1>Looking for a movie...</h1>
      </div>
      <SearchInput
        searchInputVal={searchInputVal}
        handleChange={handleChange}
      />
      <SearchList searchListVal={searchListVal} />
    </div>
  );
};
