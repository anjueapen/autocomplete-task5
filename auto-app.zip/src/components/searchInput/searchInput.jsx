import { useEffect } from "react";
import "./searchInput.css";

export const SearchInput = ({ searchInputVal, handleChange }) => {
  return (
    <div className="input-container">
      <input type="text" placeholder="search here" onChange={handleChange} />
      <button>
        <img
          height="32px"
          width="32px"
          src="https://logowik.com/content/uploads/images/close1437.jpg"
          alt=""
        />{" "}
      </button>
    </div>
  );
};
